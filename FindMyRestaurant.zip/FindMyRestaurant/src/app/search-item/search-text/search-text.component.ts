import { Component, OnInit } from '@angular/core';
import {SearchComponentService} from '../../main-component-services/search-component.service';
@Component({
  selector: 'app-search-text',
  templateUrl: './search-text.component.html',
  styleUrls: ['./search-text.component.css']
})
export class SearchTextComponent implements OnInit {

  constructor(private  searchService:SearchComponentService) { }

  ngOnInit() {
  }
   searchClose()
   {
      this.searchService.serviceActive.next('app-main-content');
   }
}
