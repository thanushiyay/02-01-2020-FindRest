import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MainContentComponent } from './main-content/main-content.component';
import { SideNavContentComponent } from './main-content/side-nav-content/side-nav-content.component';
import { PopularBrandsComponent } from './main-content/popular-brands/popular-brands.component';
import { CarouselContentComponent } from './main-content/carousel-content/carousel-content.component';
import { HeaderComponent } from './header/header.component';
import { SearchByTimeComponent } from './main-content/search-by-time/search-by-time.component';
import {SearchComponent} from './header/search/search.component';
import {SignInComponent}  from './header/sign-in/sign-in.component';
import {CartComponent} from './header/cart/cart.component';
import {DetectLocationComponent} from './header/detect-location/detect-location.component';
import {HeaderLogoComponent} from './header/header-logo/header-logo.component';
import {NotificationsComponent}  from './header/notifications/notifications.component';
import { CarouselModule } from 'ngx-owl-carousel-o';
import { SearchItemComponent } from './search-item/search-item.component';
// formsModule
import {FormsModule}  from '@angular/forms';
import { SearchTextComponent } from './search-item/search-text/search-text.component';
import { RecentSearchesComponent } from './search-item/recent-searches/recent-searches.component';
import { CarouselHeaderComponent } from './notifications-details/carousel-header/carousel-header.component';
import { NotificationsDetailsComponent } from './notifications-details/notifications-details.component';
import { CarouselComponent } from './notifications-details/carousel/carousel.component';
import { RestaurantOffersComponent } from './notifications-details/restaurant-offers/restaurant-offers.component';
import { PaymentOffersComponent } from './notifications-details/payment-offers/payment-offers.component';
@NgModule({
  declarations: [
    AppComponent,
    MainContentComponent,
    SideNavContentComponent,
    PopularBrandsComponent,
    CarouselContentComponent,
    HeaderComponent,
    SearchByTimeComponent,
    SearchComponent,
    SignInComponent,
    CartComponent,
    DetectLocationComponent,
    HeaderLogoComponent,
    NotificationsComponent,
    SearchItemComponent,
    SearchTextComponent,
    RecentSearchesComponent,
    NotificationsDetailsComponent,
    CarouselComponent,
    CarouselHeaderComponent,
    RestaurantOffersComponent,
    PaymentOffersComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CarouselModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
