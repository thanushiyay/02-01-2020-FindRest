import { TestBed } from '@angular/core/testing';

import { SearchComponentService } from './search-component.service';

describe('SearchComponentService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SearchComponentService = TestBed.get(SearchComponentService);
    expect(service).toBeTruthy();
  });
});
