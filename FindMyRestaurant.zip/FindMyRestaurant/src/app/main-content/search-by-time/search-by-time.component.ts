import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-search-by-time',
  templateUrl: './search-by-time.component.html',
  styleUrls: ['./search-by-time.component.css']
})
export class SearchByTimeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
