import { Component, OnInit } from '@angular/core';
import { OwlOptions } from 'ngx-owl-carousel-o';
// import {OwlOptions}  from ''
@Component({
  selector: 'app-carousel-content',
  templateUrl: './carousel-content.component.html',
  styleUrls: ['./carousel-content.component.css']
})
export class CarouselContentComponent implements OnInit {

  constructor() { }
  carousel_arr:string[]=[];
  ngOnInit() {
    this.carousel_arr=[
      '../../../assets/images/carousel_1.jpg',
      '../../../assets/images/carousel_1.jpg',
      '../../../assets/images/carousel_1.jpg'
    ]
  }
  customOptions: OwlOptions = {
    loop: false,
    mouseDrag: false,
    touchDrag: false,
    pullDrag: false,
    dots: false,
    navSpeed: 600,
    navText: ['<h5 class="fa fa-angle-left"></h5>', '<h5 class="fa fa-angle-right"></h5>'],
    responsive: {
      0: {
        items: 1
      },
      30: {
        items: 2
      },
      60: {
         items: 3
       },
      90: {
         items: 4
       },
       120: {
        items: 5
      },
      150:
      {
        items:6
      }
 
    },
    nav: true
  }

}
