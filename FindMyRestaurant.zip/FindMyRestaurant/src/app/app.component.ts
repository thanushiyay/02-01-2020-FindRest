import { Component, OnInit } from '@angular/core';
import {SearchComponentService} from './main-component-services/search-component.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  isActive: boolean=false;
  constructor(private searchService:SearchComponentService){}
  tagName;
  ngOnInit(): void {
      this.searchService.serviceActive.subscribe((data)=>
      {
               this.tagName=data;
               this.isActive=true;
              //  console.log("hiiii"+this.tagName);
      });
     
  }
  title = 'FindMyRestaurant';
}
