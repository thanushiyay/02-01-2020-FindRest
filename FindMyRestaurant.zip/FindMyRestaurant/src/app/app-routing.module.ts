import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchItemComponent } from './search-item/search-item.component';
import { NotificationsDetailsComponent } from './notifications-details/notifications-details.component';


const routes: Routes = [
  {
    path:'search',component:SearchItemComponent
  },
  {
    path:'offers',component:NotificationsDetailsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
