import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-notifications-details',
  templateUrl: './notifications-details.component.html',
  styleUrls: ['./notifications-details.component.css']
})
export class NotificationsDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
