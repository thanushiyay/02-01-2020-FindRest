import { Component, OnInit, RootRenderer } from '@angular/core';
import {SearchComponentService} from '../main-component-services/search-component.service';
import {Pipe} from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  activated: boolean;
  prev: any=null;

  constructor(private  searchService:SearchComponentService) { }
  activeClass:string;
  disable: boolean;
  ngOnInit() {
    this.searchService.serviceActive.subscribe((data)=>
    {
            if(data == 'app-main-content')
            {
                 this.prev.style.color='black';
            }
    });
  }
  tagName;
  changeCss(event:Event)
  {
      if(this.prev!=null)
      {
        this.prev.style.color='black';
      }
      const className=event["path"][1];
      this.tagName=className.tagName.toLowerCase();
       className.style.color='rgb(94, 117, 17)';
      if(this.tagName == 'app-search' || this.tagName == 'app-notifications' || this.tagName == 'app-sign-in' || 
      this.tagName == 'app-cart')
      { 
        this.searchService.serviceActive.next(this.tagName);  
      }
      this.prev=className;    
  }
}
