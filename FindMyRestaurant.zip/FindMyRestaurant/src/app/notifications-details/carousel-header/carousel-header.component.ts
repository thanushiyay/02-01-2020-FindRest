import { Component, OnInit } from '@angular/core';
import { concat } from 'rxjs';
import {NotificationsService}  from '../../main-component-services/notifications/notifications.service';
@Component({
  selector: 'app-carousel-header',
  templateUrl: './carousel-header.component.html',
  styleUrls: ['./carousel-header.component.css']
})
export class CarouselHeaderComponent implements OnInit {
  clicked: string;
  restClicked: boolean=true;
  payClicked: boolean;

  constructor(private notificationsService:NotificationsService) { }

  ngOnInit() {
  }
  
  onClicked(value:string)
  {
    console.log(value);
         if(value == 'rest')
         {
            this.restClicked=true;
            this.notificationsService.offersService.next('restClicked');
            this.payClicked=false;
         }
         if(value == 'pay')
         {
          this.restClicked=false;
          this.notificationsService.offersService.next('payClicked');
            this.payClicked=true;
         }
  }
}
