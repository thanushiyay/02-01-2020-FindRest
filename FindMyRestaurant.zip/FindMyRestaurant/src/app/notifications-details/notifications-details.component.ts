import { Component, OnInit } from '@angular/core';
import {NotificationsService} from '../main-component-services/notifications/notifications.service';
@Component({
  selector: 'app-notifications-details',
  templateUrl: './notifications-details.component.html',
  styleUrls: ['./notifications-details.component.css']
})
export class NotificationsDetailsComponent implements OnInit {
  

  constructor(private notificationsService:NotificationsService) { }
  offersShow='restClicked';
  ngOnInit() {
    this.notificationsService.offersService.subscribe((data :string)=>
    {
            this.offersShow=data;
    });
  }
  

}
