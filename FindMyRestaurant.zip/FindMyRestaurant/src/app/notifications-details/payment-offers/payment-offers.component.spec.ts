import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentOffersComponent } from './payment-offers.component';

describe('PaymentOffersComponent', () => {
  let component: PaymentOffersComponent;
  let fixture: ComponentFixture<PaymentOffersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentOffersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentOffersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
