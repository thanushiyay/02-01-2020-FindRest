import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-offers',
  templateUrl: './payment-offers.component.html',
  styleUrls: ['./payment-offers.component.css']
})
export class PaymentOffersComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
